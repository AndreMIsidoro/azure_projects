package com.example.azureentraapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureentraappApplicationTests {

	@Test
	void contextLoads() {
	}

}
